package com.MAP1;
public class Employee{
	private String name;
	@Override
	public String toString() {
		return "Employee [name=" + name + ", city=" + city + ", age=" + age + ", rollId=" + rollId + ", domain="
				+ domain + "]";
	}
	private String city;
	private int age;
	private int rollId;
	private String domain;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Employee(String name, String city, int age, int rollId, String domain) {
		super();
		this.name = name;
		this.city = city;
		this.age = age;
		this.rollId = rollId;
		this.domain = domain;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getRollId() {
		return rollId;
	}
	public void setRollId(int rollId) {
		this.rollId = rollId;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
		
}