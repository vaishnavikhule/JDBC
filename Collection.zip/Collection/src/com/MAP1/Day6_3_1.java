package com.MAP1;

public class Day6_3_1 {
private String name="Eshan";
private String city;
private int rollNo;
private int number;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getRollNo() {
	return rollNo;
}
public void setRollNo(int rollNo) {
	this.rollNo = rollNo;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
@Override
public String toString() {
	return "Day6_3 [name=" + name + ", city=" + city + ", rollNo=" + rollNo + ", number=" + number + "]";
}

}
