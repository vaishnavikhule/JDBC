package com.MAP1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Day6_1 {
	public static void main(String[] args) {

		List<String> chem = new ArrayList();
		chem.add("FE");
		chem.add("SE");
		chem.add("TE");
		chem.add("BE");

		List<String> mech = new ArrayList();
		mech.add("FE");
		mech.add("SE");
		mech.add("TE");
		mech.add("BE");

		List<String> civil = new ArrayList();
		civil.add("FE");
		civil.add("SE");
		civil.add("TE");
		civil.add("BE");

		List<String> comp = new ArrayList();
		comp.add("FE");
		comp.add("SE");
		comp.add("TE");
		comp.add("BE");

		HashMap<String, List<String>> college = new HashMap();
		college.put("Chemical", chem);
		college.put("Mechanical", mech);
		college.put("Civil", civil);
		college.put("Computer", comp);
		System.out.println(college);

		HashMap<String, HashMap<String, List<String>>> MIT = new HashMap();
		MIT.put("MIT", college);
		System.out.println(MIT);

		Set<String> set = MIT.keySet();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String a = itr.next();
			System.out.println(a + "," + MIT.get(a));

			for (String b : set) {
				System.out.println(b + "," + MIT.get(b));

				set.forEach(c -> System.out.println(c));
			}

		}
	}
}