package com.MAP1;

import java.util.HashMap;

public class Day6_3_2 {
public static void main(String[] args) {
	HashMap<Day6_3_1,String>hm=new HashMap();
	Day6_3_1 obj=new Day6_3_1();
	hm.put(obj,obj.getName());
	System.out.println(hm);
}
}
