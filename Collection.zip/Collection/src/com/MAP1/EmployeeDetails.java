package com.MAP1;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.MAP1.Employee;

public class EmployeeDetails {
	
		public List<Employee> addEmployee() {
			ArrayList<Employee> al1=new ArrayList<Employee>();
			al1.add(new Employee("Vaishnavi","Nashik",52,25,"Electrical"));
		System.out.println(al1);
		
		
		Iterator itr=al1.iterator();
		while(itr.hasNext()) {
		System.out.println(itr.next());
		}
		for(Object a:al1) {
			System.out.println(a);
		}
		
			return new ArrayList();
		}
		public static void main(String[] args) {
			EmployeeDetails emp1=new EmployeeDetails();
			emp1.addEmployee();
		/*	ArrayList <Employee> al=new ArrayList();
			al.add(new Employee("Ram","Pune",52,25,"Electrical"));
			System.out.println(al);*/
			
			
			
			
		 /*	ArrayList<Employee> al=new ArrayList();
	Employee emp=new Employee();  
			emp.setName("Vaishnavi");
			emp.setCity("Nashik");
			emp.setDomain("Chemical");
			emp.setAge(23);
			emp.setRollId(795621321);
			al.add(emp);
			System.out.println(al);*/
			
			
			
		}
	}


