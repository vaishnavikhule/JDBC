package com.MAP1;

import java.util.HashMap;
import java.util.Map;

public class Day6_2 {
	public HashMap <Integer,String> m1(){
HashMap<Integer,String>hm=new HashMap();
hm.put(25, "Vaishnavi");
hm.put(55, "Archana");
hm.put(85, "Sandip");
System.out.println(hm);
return new HashMap();
}
	public static void main(String[] args) {
		Day6_2 obj=new Day6_2();
		obj.m1();
		
		System.out.println("2nd way to print");
		HashMap<Integer,String>hm1 =obj.m1();
		
		System.out.println("3rd way to print");
		Map<Integer,String>hm2=obj.m1();
		
		} 
}