package com.c;

import java.util.LinkedList;

public class Linklist1 {
	public static void main(String[] args) {

		LinkedList ls = new LinkedList();
		for(int i=1;i<=10;i++) {
	ls.add(i);
		}			System.out.println(ls);

		ls.add(10);
		ls.add(50);
		ls.add("Vaishnavi");
		ls.add(95);
		ls.add(50);
		ls.add(60);
		System.out.println(ls);
		ls.addFirst(52);
		ls.addLast(96);
		ls.add(5, "Chikuu");
		System.out.println(ls);
		LinkedList ls1 = new LinkedList();
ls1.add(50);
ls1.add("Vaishhhh");
		System.out.println(ls.addAll(ls1));
		System.out.println(ls);
		System.out.println(ls.getFirst());
		System.out.println(ls.remove(6));
		
	}
}