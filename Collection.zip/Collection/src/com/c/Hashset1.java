package com.c;

import java.util.HashSet;

/*//Set:
//Set is the child interface of collection interface
//It is present in java.util package
//When we want to represent group of object into single entity where insertion order is
 not preserved and duplicates are not allowed then we should go for set.
 #HashSet:
 Hashset implements Set interface
 //Underline data structure forHashset is Hashtable
 2Null insertion is allowed only once
 3Insertion order is not preserved
4. Duplicate elements are not allowed;
 5.If we are trying to insert duplicate elements then we wont get any runtime or compile time error but
 elements will get print only once
 6.heterogeneous elements are allowed 
 7.Hashset is the best choice if our frequent operation is search operation
 8.HashSet implements Serializable,Cloneable but not random access interface;*/
public class Hashset1 {
public static void main(String[] args) {
	HashSet s=new HashSet();
	s.add(10);
	s.add(null);
	s.add(null);
	s.add("Vaishnavi");
			s.add(10);
			System.out.println(s);
}
}
