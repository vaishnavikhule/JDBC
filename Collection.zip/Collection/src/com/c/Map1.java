package com.c;
//#MAP is not the child interface of collection
//When we want to represent group of objects in the form of key and value then we should go for map.
//both key and value are objects.//Duplicate key is not allowed.values may be duplicate


//#HASHMAP
/*HashMap is a class which implements Map interface
 * 
 * 
 * 
 * 
 */
import java.util.HashMap;

public class Map1 {
	public static void main(String[] args) {
		HashMap hm=new HashMap();
		hm.put(2, "Vaishnavi");
		hm.put(5, 52);
		hm.put(9, "852");
		hm.put(1, 74);
		hm.put("maju nko", 52);
		hm.put(2,"52");
		hm.put(2, "jbbjb");
		System.out.println(hm);
	}
}
