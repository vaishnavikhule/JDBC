package com.c;

import java.util.TreeMap;

//#TreeMap
/*TreeMap is class which implements Navigable map interface which is child interface of sorted map
 * It stores value based on key
 * Every key must be unique
 * It is ordered but in ascending manner
 * Null key is possible we wont get any compile time but we get runtime error
 * 
 */
public class TreeMap1 {
public static void main(String[] args) {
	TreeMap tm=new TreeMap();
	tm.put(2, 52);
	tm.put(52, null);
	tm.put(2, 523);
	tm.put(25, 8656);
	tm.put(27, 52865);

System.out.println(tm);
}
}
