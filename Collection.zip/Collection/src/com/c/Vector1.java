package com.c;

import java.util.Vector;

public class Vector1 {
	public static void main(String[] args) {
		Vector<String> v=new Vector();
		v.add("Chiku");
		v.add("Cat");
		v.add("Abhi");
		v.add("Treee");
System.out.println(v);
System.out.println(v.size());
	}
}