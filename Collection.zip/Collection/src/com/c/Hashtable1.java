package com.c;

import java.util.Hashtable;

/*#	HASHTABLE
 * Hashtable is a class which implements map interface and extends Dictionary class
 * Its stores values based on key
 * every key must be unique
 * It is unordered
 * It is a legacy class,Hashtable has synchronized methods,so thos class is thread safe
 * and  low in performance
 * null insertion for key and value is not allowed if we are trying to insert then we wont get any compile time 
 * error nut we get runtime error 
 */
public class Hashtable1 {
public static void main(String[] args) {
	Hashtable ht=new Hashtable();
	ht.put(20, 25);
	ht.put(21, 11);
	ht.put(20, "Vaishnavi");
	ht.put(55, "Saket");
	ht.put(15, "Ram");
	ht.put(25, "rakesh");

System.out.println(ht);
}
}
