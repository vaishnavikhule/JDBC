package com.c;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class ArraylistDuplicate {
public static void main(String[] args) {
	ArrayList al=new ArrayList();
	al.add(10);
	al.add(20);
	al.add(50);
	al.add(70);
	al.add(10);
	al.add(20);
	al.add(30);
	al.add(40);
	System.out.println("ArrayList with duplicate elements");
	System.out.println(al);
	
	LinkedHashSet hs=new LinkedHashSet(al);
	System.out.println("ArrayList without duplicate elements");

	System.out.println(hs);
	}
		

}

