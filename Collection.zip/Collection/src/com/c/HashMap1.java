package com.c;

import java.util.HashMap;

//#HASHMAP
/*HashMap is a class which implements map interface
 * It stores value based on key
 * every key must be unique
 * it is unordered but we get sorted order
 * for adding element in hashmap we have put method 
 * This method has return type as object
 * null key and null values are allowed
 * It has 16 size internally,it get increase size by double
 */
public class HashMap1 {
public static void main(String[] args) {
	HashMap hm=new HashMap();
	hm.put(null, null);
	hm.put(45, 85);
	hm.put(null, 256);
	hm.put(56, null);
	hm.put(85, "Vaishnavi");
	hm.put("Abhishek", 85);
	hm.put("Chiku", "Sanket");
	System.out.println(hm);
}
}
