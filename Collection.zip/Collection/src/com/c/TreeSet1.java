package com.c;

import java.util.TreeSet;
/*TreeSet is Child Inreface of Set
 * Underline data Structure for TreeSet is BAlanced Tree
 * Null insertion is not alllowed if we are trying we dont get any compile time but we get 
 * runtime error as nullpointerException
 * Heterogeneous elements are not allowed
 * Duplicate elements are not allowed at runtime we get classcastException
 * Insertion order is not preserved but we get sorted order
 * 
 * 
 * 
 * 
 * 
 * 
 */
public class TreeSet1 {
public static void main(String[] args) {
	TreeSet ts=new TreeSet();
	
	ts.add("Vaishnavi");
	ts.add("Abhi");
	


System.out.println(ts);
}
}
