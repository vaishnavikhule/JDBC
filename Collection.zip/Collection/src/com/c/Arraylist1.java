package com.c;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Arraylist1{
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add(10);
		al.add("Ram");
		al.add(20);
		al.add("Vaishnavi");
		al.add(80);
		al.add(55);
		al.add(85);
		System.out.println(al);
		
		ArrayList<Integer>al1=new ArrayList();
		al1.add(41);
		al1.add(52);
		al1.add(78);
		al1.add(74);
		al1.add(20);
		System.out.println(al1);
		
		al.addAll(al1);
	System.out.println(al);
		
		Iterator ire =al.iterator();
		while(ire.hasNext()) {
			System.out.println(ire.next());
		}
		for(Object a:al) {
			System.out.println(a);
		}
		al.forEach(b->System.out.println(b));
		
		ArrayList <String>al3=new ArrayList();
		al3.add("Vaishnavi");
		al3.add("Abhiii");
		al3.add("Chiku");
		al3.add("Abhishek");
		Collections.sort(al3);
System.out.println(al3);

	}
}