package com.c;

import java.util.LinkedHashSet;

/*Linked Hashlist was introduced in version 1.4
 2.It is same as Hashset but here insertion order is preserved
 Underline data structure for linked Hashset is hashtable and LinkedList*/
public class LinkedHashset1 {
	public static void main(String[] args) {
		
	
	LinkedHashSet lhs=new LinkedHashSet();
	lhs.add(10);
	lhs.add("Vaishnavi");
	lhs.add(500);
	lhs.add(null);
	lhs.add(10);
System.out.println(lhs);
	}
}
	
/*Difference betn Hashset and linkedHashset
 * Hashset was introduced in version 1.2
 * LinkedHashSet was introduced in version 1.4
 * For HashSet insertion order is not preserved 
 * For LinkedHashSet insertion orderr is preserved
 * Underline Data Structure for HashSet is Hashtable
 * Underline Data Structure for LinkedHashSet is Hashtable+Linked list
 */
	
	
	
	
	
	