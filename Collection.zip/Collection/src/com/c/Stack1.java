package com.c;

import java.util.Stack;

public class Stack1 {
public static void main(String[] args) {
	Stack s=new Stack();

	s.add(52);
	s.add(52);
	s.add(52);
	s.add(52);
	s.add(52);
	s.push(56);
	s.push("Vaishnavi");
	s.push("789");

	System.out.println(s);
	System.out.println(s.peek());
	System.out.println(s.pop());
	System.out.println(s);
}
}