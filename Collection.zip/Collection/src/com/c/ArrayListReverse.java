package com.c;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListReverse {
	public static void main(String[] args) {
		List al = new ArrayList();
		al.add(10);
		al.add(35);
		al.add(78);
		al.add(66);
		System.out.println("Before reverse ArrayList");
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		Iterator itr2 = al.iterator();
		Collections.reverse(al);
		System.out.println("List in reverse order");
		while (itr2.hasNext()) {
			System.out.println(itr2.next());
		}
	}
}
