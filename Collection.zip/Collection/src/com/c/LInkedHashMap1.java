package com.c;
//#LINKEDHASHMAP
/*LinkedHashMap is a hashtable and linked list implementation of map interface with a predictable
 * iteration order 
 * It is same as hashmap but here insertion order is preserved
 * 
 * 
 */
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

public class LInkedHashMap1 {
public static void main(String[] args) {
	LinkedHashMap<Integer,String> lhm=new LinkedHashMap();
	lhm.put(10,"Vaishnavi");
	lhm.put(50, "Chikuuuu");
	lhm.put(85, "Abhi");
	System.out.println(lhm);
	
	Set<Integer>s=lhm.keySet();
	Iterator<Integer>itr=s.iterator();
	while(itr.hasNext()) {
		int a=itr.next();
		//System.out.println("Key="+a);
	//	System.out.println("Value="+lhm.get(a));
		System.out.println(a+","+lhm.get(a));
	}
	for(int b:s) {
		System.out.println(b+","+lhm.get(b));
	}
}
}










