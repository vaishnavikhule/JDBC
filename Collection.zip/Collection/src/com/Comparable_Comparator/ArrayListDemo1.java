package com.Comparable_Comparator;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListDemo1 {
public static void main(String[] args) {
	ArrayList<Student> al=new ArrayList();
	al.add(new Student(75,"Abhishek","Pune",11,554) );
	al.add(new Student(55,"Chiku","Satara",255,5656) );
	al.add(new Student(45,"Vaishnavi","Nashik",25,452) );
	al.add(new Student(456,"Vishu","Akola",25,452) );

	//System.out.println(al);
	//Collections.sort(al);
	//System.out.println(al);
	Collections.sort(al,new NameCom());
	System.out.println(al);
} 
}
