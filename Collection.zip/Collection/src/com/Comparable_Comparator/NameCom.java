package com.Comparable_Comparator;

import java.util.Comparator;

public class NameCom implements Comparator<Student>{

	@Override
	public int compare(Student stu1, Student stu2) {
	/*	if(stu1.getNumber()==stu2.getNumber())
			return 0;
		else if(stu1.getNumber()>stu2.getNumber())
		return -1;
		else
			return 1;*/
		return stu1.getName().compareTo(stu2.getName());
	}

}
